INSERT INTO Team VALUES (100, 'Olympiakos', 'Mpartzokas', 'Pireus', 'SEF');
INSERT INTO Team VALUES (101, 'Panathinaikos', 'Ataman', 'Athens', 'O.A.C.A. Olympic Indoor Hall');
INSERT INTO Team VALUES (102, 'Peristeri', 'Spanoulis', 'Peristeri', 'Peristeri arena');
INSERT INTO Team VALUES (103, 'Paok', 'Takianos', 'Thessaloniki', 'PAOK Sports Arena');
INSERT INTO Team VALUES (104, 'Promitheas', 'Papatheodorou', 'Patra', 'Dimitris Tofalos Arena
');
INSERT INTO Team VALUES (105, 'AEK', 'PLATHA', 'ATHENS', 'OKAL');
INSERT INTO Team VALUES (106, 'KOLOSOS', 'SEGKOURA', 'RODOS', 'KALITHEAS ARENA');
INSERT INTO Team VALUES (107, 'ARIS', 'KASTRITIS', 'Thessaloniki', 'ALEXANDREIO');
INSERT INTO Team VALUES (108, 'LAURIO', 'LIMNIATIS', 'LAURIO', 'LAURIOTIKHS ARENA');
INSERT INTO Team VALUES (109, 'KARDITSA', 'PAPANIKOLOPOULOS', 'KARDITSA', 'N.K.G.');
INSERT INTO Team VALUES (110, 'APOLLON', 'BETOULAS', 'PATRA', 'K.G. APOLLON');
INSERT INTO Team VALUES (111, 'IONIKOS', 'LIVANOS', 'ATHENS', 'K.G. NIKAIAS');
