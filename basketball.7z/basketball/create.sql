CREATE TABLE Team (
    TeamId NUMBER NOT NULL,
    TeamName VARCHAR2(100) NOT NULL,
    CoachName VARCHAR2(100) NOT NULL,
    City VARCHAR2(100) NOT NULL,
    Arena VARCHAR2(100) NOT NULL,
    PRIMARY KEY (TeamId)
);

CREATE TABLE Player (
    PlayerID NUMBER NOT NULL,
    Fname VARCHAR2(100) NOT NULL,
    Lname VARCHAR2(100) NOT NULL,
    BirthDate DATE NOT NULL,
    TeamId NUMBER NOT NULL,
    Num NUMBER NOT NULL,
    POSITION VARCHAR2(3) NOT NULL,
    ALT_POSITION VARCHAR2(3),
    PRIMARY KEY (PlayerID),
    FOREIGN KEY (TeamId) REFERENCES Team(TeamId)
);

CREATE TABLE Game (
    GameId NUMBER NOT NULL,
    Gdate DATE NOT NULL,
    HomeTeamID NUMBER NOT NULL, 
    AwayTeamID NUMBER NOT NULL, 
    HomeTeamScore NUMBER NOT NULL,
    AwayTeamScore NUMBER NOT NULL,
    PRIMARY KEY (GameId),
    FOREIGN KEY (HomeTeamID) REFERENCES Team(TeamId),
    FOREIGN KEY (AwayTeamID) REFERENCES Team(TeamId)
);

/*Stats only for the 5 main players for every team , due to lack of data */
CREATE TABLE Stats (
    PlayerID NUMBER NOT NULL,
    GameNum NUMBER NOT NULL,
    PointsScored NUMBER NOT NULL,
    Assists NUMBER NOT NULL,
    Rebounds NUMBER NOT NULL,
    Steals NUMBER NOT NULL,
    FOREIGN KEY (PlayerID) REFERENCES Player(PlayerID)
);
CREATE TABLE Standings (
    TeamID NUMBER NOT NULL,
    lRank NUMBER,
    Wins NUMBER,
    Losses NUMBER,
    PPG NUMBER(2,2),
    RPG NUMBER(2,2),
    APG NUMBER(2,2),
    FOREIGN KEY (TeamID) REFERENCES Team(TeamId)
);

