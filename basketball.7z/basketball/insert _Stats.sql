INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (1001, 22, 102, 124, 50, 32);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (1006, 21, 358, 46, 129, 23);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (1012, 17, 121, 32, 75, 8);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (1013, 20, 170, 67, 55, 15);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (1003, 20, 122, 39, 40, 19);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (1002, 16, 160, 17, 18, 9);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2008, 21, 128, 20, 43, 13);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2005, 20, 230, 80, 37, 40);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2014, 16, 210, 34, 63, 11);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2006, 21, 228, 30, 127, 8);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2003, 20, 111, 25, 65, 14);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2004, 14, 85, 37, 43, 15);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (3002, 22, 284, 40, 176, 11);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (3010, 22, 375, 53, 46, 34);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (3003, 21, 240, 113, 64, 32);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (3011, 19, 185, 27, 80, 7);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (2004, 18, 59, 24, 29, 14);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (4014, 22, 359, 61, 110, 18);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (4009, 20, 59, 5, 31, 8);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (4012, 21, 112, 29, 52, 18);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (4010, 21, 171, 57, 124, 30);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (4007, 18, 182, 76, 36, 15);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (5014, 22, 227, 129, 60, 23);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (5006, 11, 93, 3, 45, 7);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (5016, 22, 285, 16, 123, 15);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (5015, 14, 171, 49, 75, 14);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (5009, 13, 104, 11, 32, 11);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (6014, 17, 112, 50, 56, 18);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (6009, 10, 94, 21, 40, 8);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (6007, 5, 22, 4, 16, 3);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (6019, 21, 222, 37, 60, 21);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (6012, 15, 134, 42, 22, 6);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (7007, 21, 122, 17, 73, 10);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (7006, 22, 201, 24, 117, 13);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (7002, 14, 152, 54, 42, 12);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (7009, 17, 176, 16, 83, 9);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (7001, 12, 16, 6, 10, 3);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (8009, 17, 175, 51, 58, 20);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (8012, 20, 273, 78, 48, 33);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (8013, 20, 246, 21, 162, 18);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (8014, 21, 329, 58, 68, 37);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (8015, 22, 123, 22, 38, 11);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (9016, 17, 120, 19, 51, 15);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (9019, 21, 304, 79, 151, 17);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (9014, 14, 174, 10, 97, 6);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (9007, 7, 4, 6, 2, 4);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (9022, 20, 276, 93, 63, 21);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (10010, 9, 116, 16, 77, 10);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (10021, 22, 146, 38, 124, 22);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (10017, 14, 72, 6, 39, 2);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (10013, 12, 44, 32, 24, 14);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (10012, 10, 207, 17, 23, 8);

INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (12014, 18, 12, 4,9, 2);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (12013, 17, 358, 49, 130, 17);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (12015, 19, 108, 83, 50, 12);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (12016, 20, 231, 31, 152, 11);
INSERT INTO Stats (PlayerID, GameNum, PointsScored, Assists, Rebounds, Steals)
VALUES (12019, 22, 188, 38, 42, 19);
