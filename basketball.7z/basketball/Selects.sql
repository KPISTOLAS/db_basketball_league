/* Best shooter  */

select Player.Fname , Player.Lname ,Team.TeamName, Stats.PointsScored FROM Stats , Team , Player 
WHERE Stats.PlayerID=Player.PlayerID AND Team.TeamId=Player.TeamId
ORDER BY Stats.PointsScored DESC
LIMIT 1;

/*Best assist man  */

select Player.Fname , Player.Lname ,Team.TeamName, Stats.Assists FROM Stats , Team , Player 
WHERE Stats.PlayerID=Player.PlayerID AND Team.TeamId=Player.TeamId
ORDER BY Stats.Assists DESC
LIMIT 1;

/*Best rebound man  */

select Player.Fname , Player.Lname ,Team.TeamName, Stats.Rebounds FROM Stats , Team , Player 
WHERE Stats.PlayerID=Player.PlayerID AND Team.TeamId=Player.TeamId
ORDER BY Stats.Rebounds DESC
LIMIT 1;

/*Best defender  */

select Player.Fname , Player.Lname ,Team.TeamName, Stats.Steals FROM Stats , Team , Player 
WHERE Stats.PlayerID=Player.PlayerID AND Team.TeamId=Player.TeamId
ORDER BY Stats.Steals DESC
LIMIT 1;


